* La prorrata especial de IVA no está contemplada.
* No se incluye la posibilidad de las facturas de actividad diferenciada, de las
  que te puedes deducir el 100% del IVA de la factura.
