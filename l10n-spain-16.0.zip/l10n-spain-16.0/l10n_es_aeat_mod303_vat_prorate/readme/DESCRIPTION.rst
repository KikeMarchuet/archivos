Este módulo contempla la casuística de prorrata en el modelo 303 cuando se han
creado ya los apuntes contables separados con el módulo `l10n_es_vat_prorate`.

Esto es necesario si se cuenta con el SII y se debe enviar la información ya
seccionada.

Para el caso de que se quiera hacer la repartición con el asiento de liquidación
del IVA, utilizar `l10n_es_aeat_vat_prorrate`.
