 Para entender el funcionamiento de la prorrata, remitirse a la configuración de
 `l10n_es_aeat_vat_prorate`.
