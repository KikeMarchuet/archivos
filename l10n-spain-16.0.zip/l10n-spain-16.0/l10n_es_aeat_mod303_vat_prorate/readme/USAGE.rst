#. Realizar la declaración 303 de la forma habitual.
#. El IVA deducible ya vendrá minorado por el porcentaje de la prorrata.
#. En la casilla 44, se mostrará el importe de la prorrata que se minoró.
