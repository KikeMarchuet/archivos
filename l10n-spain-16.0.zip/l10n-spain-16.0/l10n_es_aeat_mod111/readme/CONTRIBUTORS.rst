* MálagaTIC (http://www.malagatic.com)
* Carlos Sánchez Cifuentes <csanchez@grupovermon.com>
* Pedro M. Baeza
* AvanzOSC (http://www.avanzosc.es)
* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* RGB Consulting SL (http://www.rgbconsulting.com)
* Vicent Cubells (http://obertix.net)
* Jose Maria Alzaga (http://www.aselcis.com)
* Ismael Calvo (http://factorlibre.com)
* Iván Antón (https://www.ozonomultimedia.com)
* Valentin Vinagre <valentin.vinagre@sygel.es>
* Arantxa Sudón (`Moduon <https://www.moduon.team/>`__)
* Rafael Blasco (`Moduon <https://www.moduon.team/>`__)
