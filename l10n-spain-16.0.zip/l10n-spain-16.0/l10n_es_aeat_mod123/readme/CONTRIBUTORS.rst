* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza

* `Sygel Technology <https://www.sygel.es>`_:

  * Valentin Vinagre
  * Manuel Regidor

* Emilio Pascual (`Moduon <https://www.moduon.team/>`__)
