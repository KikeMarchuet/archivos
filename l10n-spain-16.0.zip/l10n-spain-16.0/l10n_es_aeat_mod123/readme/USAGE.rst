Para introducir datos válidos para el modelo:

#. Realizar una factura de proveedor de los intereses cobrados por la empresa
   o particular prestatario con impuesto "Retenciones 19% (préstamos)".
#. O también puede realizar una factura de proveedor del reparto de dividendos
   con el impuesto "Retenciones 19% (dividendos)".
#. Validarla.

Para crear una declaración del modelo:

#. Ir a *Facturación > Informes AEAT > Modelo 123*.
#. Pulsar en el botón "Crear".
#. Seleccionar el ejercicio fiscal y el tipo de período. Los periodos incluidos
   se calculan automáticamente.
#. Seleccionar el tipo de declaración.
#. Rellenar el teléfono, necesario para la exportacion BOE.
#. Guardar y pulsar en el botón "Calcular".
#. Cuando revise los valores, pulse en el botón "Confirmar".
#. Se puede exportar la declaración en formato BOE para presentarla
   telemáticamente en el portal de la AEAT.
