
* Juan Vicente Pascual (http://www.puntsistemes.com)
* Pedro Ortega (http://www.puntsistemes.com)
* Enric Tobella <etobella@creublanca.es>
* Nestor Torres (https://www.vunkers.com)
* Marc Sánchez Fauste (https://www.vunkers.com)
* Manuel Regidor González (https://www.sygel.es)

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
