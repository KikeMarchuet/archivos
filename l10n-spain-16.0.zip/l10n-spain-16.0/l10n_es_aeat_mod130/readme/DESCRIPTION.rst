Módulo para la presentación del modelo 130 (Pago fraccionado IRPF - Impuesto
sobre la Renta de las Personas Físicas - para empresarios y profesionales en
estimación directa) de la Agencia Española de Administración Tributaria.
Instrucciones del modelo: http://goo.gl/StTY2h

Incluye la exportación al formato BOE para su uso telemático.
