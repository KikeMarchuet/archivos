Módulo ampliación del modelo 303 (IVA - Autodeclaración) para
incluir los datos de la ventanilla única o One-Stop Shop (OSS).
