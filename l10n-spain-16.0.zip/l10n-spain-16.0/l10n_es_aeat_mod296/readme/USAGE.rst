Para crear un modelo, por ejemplo de un trimestre del año:

1. Ir a Contabilidad > Informe > Informes legales > Declaraciones AEAT > Modelo 296
2. Pulsar en el botón "Crear"
3. Seleccionar el ejercicio fiscal y el tipo de período, los periodos incluidos
   se calculan automáticamente
4. Seleccionar el tipo de declaración
5. Rellenar el teléfono, necesario para la exportacion BOE
6. Guardar y pulsar en el botón "Calcular"
7. Rellenar (si es necesario) aquellos campos que Odoo no calcula automáticamente:

   * Retenciones ingresadas: Casilla [04]

8. Cuando los valores sean los correctos, pulsar en el botón "Confirmar"
9. Podemos exportar en formato BOE para presentarlo telemáticamente en el portal
   de la AEAT
