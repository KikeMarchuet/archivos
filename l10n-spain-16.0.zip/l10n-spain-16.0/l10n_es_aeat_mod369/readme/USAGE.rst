Ir a:

* Contabilidad / Informes AEAT / Modelo 369
* Crear un nuevo registro e informar los datos básicos de la declaración.
* Pulsar 'Calcular' y revisar el resultado. Pulsar el botón 'Imprimir' para
  obtener el resultado en PDF.

Consideraciones importantes:

* Configurar los impuestos OSS con el campo nuevo de "Tipo de impuesto" para que sea Estándar o Reducido
