Módulo para la presentación del modelo 369 (IVA. Regímenes especiales aplicables a las prestaciones de servicios y ventas a distancia de bienes.) de la
Agencia Española de Administración Tributaria.

Instrucciones del modelo: https://sede.agenciatributaria.gob.es/static_files/Sede/Consultas_Inf/Presentacion_declaraciones/IVA_mensuales_trimestrales/Modelo_369/Descripcion_PresentacionFichero369_v1.pdf

Ayuda técnica, incluye fichero Excel de config: https://sede.agenciatributaria.gob.es/Sede/ayuda/consultas-informaticas/presentacion-declaraciones-ayuda-tecnica/modelo-369.html

Incluye la exportación al formato BOE para su uso telemático y la creación
del asiento de regularización de las cuentas de impuestos.

* Por ahora, solo contempla el caso de una declaración de Unión
  que usa la pestaña de 4. Entregas de bienes expedidos o transportados desde EMID España.
