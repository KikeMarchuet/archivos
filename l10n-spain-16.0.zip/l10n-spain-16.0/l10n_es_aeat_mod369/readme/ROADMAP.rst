* Modificar el módulo l10n_eu_oss para separar los impuestos OSS
  en Bienes y Servicios. Con esto podemos usar las pestañas 3 y 5
* Realizar las pestañas 5 y 6 Unión, para los EM distintos de España.
* Realizar la pestaña 7 Unión de Correcciones de autoliquidaciones de periodos anteriores
* Crear páginas complementarias si se exceden los 28 impuestos diferentes
* Realizar las declaraciones de Importación y Exterior a la UE
