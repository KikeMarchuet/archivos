* `Studio73 <https://www.studio73.es>`__:

  * Ethan Hildick

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
  * Pedro M. Baeza

* `Planeta Huerto <https://www.planetahuerto.es>`_:

  * Juanjo Algaz

* `FactorLibre <https://factorlibre.com>`_:

  * Aritz Olea
