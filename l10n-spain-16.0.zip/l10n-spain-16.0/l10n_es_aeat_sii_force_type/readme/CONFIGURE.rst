Habilitar dentro de las posiciones fiscales la opción de forzar el "Tipo de Comunicación" para el SII.
