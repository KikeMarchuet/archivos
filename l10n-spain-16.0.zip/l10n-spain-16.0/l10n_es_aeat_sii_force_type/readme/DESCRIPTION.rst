El objetivo del módulo es poder remitir correctamente al SII las devoluciones de IVA en Régimen Especial de Viajeros.
En el caso de facturas con el tipo de comunicación A4, A5 y A6, los importes se enviarán en negativo para los apartados ImporteTotal, CuotaRepercutida y BaseImponible.
