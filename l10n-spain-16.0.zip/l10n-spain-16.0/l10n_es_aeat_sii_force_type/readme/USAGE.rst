Desde la pestaña *SII* de la configuración de una posición fiscal, se puede
configurar si *Forzar tipo de comunicación*, en cuyo cayo se podrá especificar
también un *Tipo de comunicación por defecto*. Cuando se realice una factura
correspondiente a una posición fiscal configurada de esta manera, se podrá
forzar un determinado tipo de configuración, que por defecto será el
configurado para la posición fiscal. Si dicho campo se deja en blanco,
prevalecerá el determinado por el módulo *l10n_es_aeat_sii*.

En el caso de facturas con el tipo de comunicación A6 (*Modificación de las
devoluciones del IVA de viajeros*), los importes se enviarán en negativo para
los apartados *ImporteTotal*, *CuotaRepercutida* y *BaseImponible*.
