Se puede utilizar de forma automática al crear o editar una empresa si
selecciona la opción de "Verificar Información de la Empresa AEAT"
o mediante el botón de "Verificar Información de la Empresa" en la pestaña
AEAT de la empresa.
