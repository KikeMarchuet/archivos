* Las facturas rectificativas que no se hayan realizado desde otra factura
  quedarán descolgadas y no se presentarán en el 349.
* Añadir aclaración de cuál es el error en los registros.
