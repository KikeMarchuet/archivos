* La API no facilita métodos para cotizar el coste real de los envíos, por lo
  que siempre se cotizan a 0. Si la cotización de envíos es necesaria,
  puede instalarse el módulo OCA `delivery_price_method` o bien personalizar
  el método de cotización para este tipo de transportista.
