Para configurar el transportista:

#. Vaya a *Inventario > Configuración > Entrega > Método de envío* y cree uno
   nuevo.
#. Escoja *GLS ASM* Como proveedor.
#. Configure los datos de servicio que tiene contratados y el producto de
   envío que desea utilizar.

Si no tiene credenciales todavía, puede poner datos inventados y dejar el
método de envío en "Entorno de prueba". Se utilizará el usuario de pruebas de
la API GLS ASM.

Si GLS cambiase en un futuro el usuario de prueba, puede cambiarlo en los
*Parámetros del sistema* en la clave `delivery_gls_asm.api_user_demo`.
