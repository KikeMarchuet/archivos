* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal
  * Víctor Martínez

* `Studio73 <https://www.studio73.es>`_:

  * Ethan Hildick
  * David López
