Debemos indicar los proveedores que son no residentes, en la ficha de la
empresa:

#. Vaya a *Contactos*.
#. Entrando al correspondiente, en la pestaña "Ventas y compras", seleccione en
   la posición fiscal la "Retención IRPF No residentes" que le corresponda.
#. Al crear facturas para dicho contacto, se mapearán los impuestos necesarios
   siempre que la línea de la factura tenga el producto informado con el
   impuesto nacional adecuado.
