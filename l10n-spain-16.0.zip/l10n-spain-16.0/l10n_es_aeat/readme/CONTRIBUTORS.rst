* Pexego (http://www.pexego.es)
* Ignacio Ibeas, Acysos (http://www.acysos.com)
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Santi Argüeso <santi@comunitea.com>
* cubells <info@obertix.net>
* AvanzOSC (http://www.avanzosc.es)
* Ainara Galdona
* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Juan Vicente Pascual <jvpascual@puntsistemes.es>
* Abraham Anes <abraham@studio73.es>
* Diagram Software S.L.
* Consultoría Informática Studio 73 S.L.
* Miquel Raïch <miquel.raich@forgeflow.com>
* Iván Antón <ozono@ozonomultimedia.com>
* Digital5 S.L.
* Valentin Vinagre <valentin.vinagre@sygel.es>
* Manuel Regidor <manuel.regidor@sygel.es>
* Jairo Llopis (https://www.moduon.team)
* Loida Vilaplana (https://www.moduon.team)
