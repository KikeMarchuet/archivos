#. Vaya a Contabilidad (Facturación) > Tablero, y escoja "Importar extracto" en
   el cuadro que corresponda con el diario de su banco.
#. Seleccione el archivo Norma 43 a importar.
#. Pulse en 'Importar'.
#. Aparecerá el asistente para conciliación inmediatamente después.
