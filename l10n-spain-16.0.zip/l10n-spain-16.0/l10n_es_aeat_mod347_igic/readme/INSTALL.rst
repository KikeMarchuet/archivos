Para instalar este modulo necesitas:

* l10n_es_igic
* l10n_es_aeat_mod347

Se instalan automáticamente si están disponibles en la lista de addons.
