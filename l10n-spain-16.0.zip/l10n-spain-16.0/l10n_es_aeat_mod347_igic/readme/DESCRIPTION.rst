Módulo para el mapeo de los impuestos de Canarias para el modelo 347 de la AEAT
