Se dispone de un campo "Cobro financiado" en el modo de pago, si se marca,
al exportar la órden de cobro con ese modo de pago nos añadirá FSDD
al identificador del fichero.
