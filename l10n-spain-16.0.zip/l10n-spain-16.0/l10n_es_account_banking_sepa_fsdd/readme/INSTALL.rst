Para instalar este módulo, es necesario tener disponible el módulo
*account_banking_sepa_direct_debit* del repositorio
https://github.com/OCA/bank-payment
