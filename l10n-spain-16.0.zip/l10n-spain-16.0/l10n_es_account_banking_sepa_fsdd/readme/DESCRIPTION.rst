Este módulo permite establecer el prefijo FSDD en el identificador de un
fichero sepa para el producto nicho de anticipos de crédito, antiguamente
exportado en el cuaderno 58.
