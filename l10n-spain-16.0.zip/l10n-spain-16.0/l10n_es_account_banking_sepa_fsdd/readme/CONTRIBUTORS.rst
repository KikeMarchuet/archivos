* Omar Castiñeira Saavedra <omar@comunitea.com>
* Jaume Planas <jaume.planas@minorisa.net>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Luis M. Ontalba
  * Pedro M. Baeza
* `Landoo <https://www.landoo.es/>`__:

  * Aritz Olea
* `Sygel <https://www.sygel.es/>`__:

  * Ángel García de la Chica  Herrera
