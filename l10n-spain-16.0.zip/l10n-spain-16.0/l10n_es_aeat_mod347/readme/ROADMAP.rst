* Permitir que un asiento (y por tanto, una factura) puede tener una fecha
  específica a efectos del modelo 347, para así cuadrar la fecha del proveedor
  con nuestro modelo aunque a efectos de IVA se declare en el siguiente
  periodo.
* Permitir indicar que una factura es de transmisión de inmuebles para tenerlo
  en cuenta en la suma de totales.
* No se incluye el cálculo automático de las claves de declaración
  C, D, E, F y G.
* Realizar declaración solo de proveedores.
* No se permite marcar las operaciones como de seguro (para entidades
  aseguradoras).
* No se permite marcar las operaciones como de arrendamiento.
* No se incluye la gestión del criterio de caja.
* No se incluye la gestión de inversión de sujeto pasivo.
* No se incluye la gestión de depósito aduanero.
* No se rellena el año origen en caso de no coincidir con el actual para las
  operaciones de efectivo.
* Las operaciones con retención o arrendamientos aparecen en el 347 por
  defecto al tener también IVA asociado. Si no se quiere que aparezcan,
  hay que marcar la empresa o la factura con la casilla de no incluir en el
  347.
