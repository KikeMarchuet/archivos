Modelo 390 de la AEAT. Declaración-resumen anual del Impuesto sobre el Valor
Añadido.
