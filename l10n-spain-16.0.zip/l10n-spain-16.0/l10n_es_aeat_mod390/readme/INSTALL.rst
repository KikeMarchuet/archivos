Este módulo requiere del módulo *account_tax_balance* que se encuentra en
https://github.com/OCA/account-financial-reporting.
