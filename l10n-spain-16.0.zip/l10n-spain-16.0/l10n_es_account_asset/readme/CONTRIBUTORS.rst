* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Antonio Espinosa
  * João Marques

* `Sygel <https://www.sygel.es>`__:

  * Valentin Vinagre
  * Manuel Regidor
