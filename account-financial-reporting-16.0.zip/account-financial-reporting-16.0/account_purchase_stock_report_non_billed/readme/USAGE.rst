To use this module, you need to:

#. Go to `Invicing > Reporting > Non Billed Stock Moves`.
#. Select a concrete date.
#. The stock moves created before this date with quantity to be invoiced, are being
   showed at the tree view.
