This module extends financial reports when needed to have dependency on sales. They are accessible under
Invoicing / Reporting / OCA accounting reports.

Add the posibility on Open Items to group by partner delivery address.
