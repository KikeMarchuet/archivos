Go on 'Invoicing' -> 'Reports' -> 'OCA accounting reports' -> 'Open Items'

When wizard is open, you need to select option grouped by Delivery Address
