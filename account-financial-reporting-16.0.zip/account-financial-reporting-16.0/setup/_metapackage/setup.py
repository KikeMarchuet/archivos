import setuptools

with open('VERSION.txt', 'r') as f:
    version = f.read().strip()

setuptools.setup(
    name="odoo-addons-oca-account-financial-reporting",
    description="Meta package for oca-account-financial-reporting Odoo addons",
    version=version,
    install_requires=[
        'odoo-addon-account_financial_report>=16.0dev,<16.1dev',
        'odoo-addon-account_financial_report_sale>=16.0dev,<16.1dev',
        'odoo-addon-account_purchase_stock_report_non_billed>=16.0dev,<16.1dev',
        'odoo-addon-account_sale_stock_report_non_billed>=16.0dev,<16.1dev',
        'odoo-addon-account_tax_balance>=16.0dev,<16.1dev',
        'odoo-addon-mis_builder_cash_flow>=16.0dev,<16.1dev',
        'odoo-addon-mis_template_financial_report>=16.0dev,<16.1dev',
        'odoo-addon-partner_statement>=16.0dev,<16.1dev',
    ],
    classifiers=[
        'Programming Language :: Python',
        'Framework :: Odoo',
        'Framework :: Odoo :: 16.0',
    ]
)
