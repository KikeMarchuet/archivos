* Jordi Ballester <jordi.ballester@forgeflow.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Simone Orsi <simone.orsi@abstract.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Damien Crier <damien.crier@camptocamp.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Thomas Rehn <thomas.rehn@initos.com>
* Andrea Gallina <4everamd@gmail.com>
* Robert Rottermann <robert@redcor.ch>
* Ciro Urselli <c.urselli@apuliasoftware.it>
* Francesco Apruzzese <opencode@e-ware.org>
* Lorenzo Battistini <https://github.com/eLBati>
* Julien Coux <julien.coux@camptocamp.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Alexis de Lattre <alexis@via.ecp.fr>
* Mihai Fekete <feketemihai@gmail.com>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Joan Sisquella <joan.sisquella@forgeflow.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Sergio Teruel
  * Ernesto Tejeda
  * João Marques
  * Alexandre D. Díaz
  * Víctor Martínez
  * Carolina Fernandez

* `Sygel <https://www.sygel.es>`__:

  * Harald Panten
  * Valentin Vinagre

* Lois Rilo <lois.rilo@forgeflow.com>
* Saran Lim. <saranl@ecosoft.co.th>
* Omar Castiñeira <omar@comunitea.com>

Much of the work in this module was done at a sprint in Sorrento, Italy in
April 2016.

* Ooops404 <https://www.ooops404.com>

  * Eduard Brahas <eduardbrhas@outlook.it>
