To use this module, you need to:

#. Go to Accounting > Reports > MIS Reporting > MIS Reports and choose "Cash Flow" report
#. You can add forecast lines on Accounting > Reports > MIS Reporting > Cash Flow Forecast Line
#. If you select on "Target Moves" the value "All Posted Entries", you will get only
   lines for already posted invoices/entries + the forecast lines.
#. Selecting "All Entries", draft invoices/entries are also included.
#. In any case, cancelled invoices/entries are not included.
