* Juan José Scarafía <jjs@adhoc.com.ar>
* Gonzalo Ruzafa <gr@adhoc.com.ar>
* Alberto Martín <alberto.martin@guadaltech.es>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
